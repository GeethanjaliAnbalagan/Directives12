// inputparent.component.ts

import { Component } from '@angular/core';

@Component({
    selector: 'app-input-parent',
    template: `
    <div>
      <h2>Parent Component</h2>
      <app-input-child [childProperty]="parentData"></app-input-child>
    </div>
  `
})
export class InputParentComponent {
    parentData: string = 'Data from parent';
}

/*

In Angular, the @Input and @Output decorators are used to enable communication 
between parent and child components by allowing data to flow from parent to child
 (via @Input) and from child to parent (via @Output).

@Input Decorator:

The @Input decorator is used to declare an input property in a child component.
It allows the parent component to pass data to the child component through binding.
To use @Input, import it from @angular/core and apply it to a property in the child component class.
*/