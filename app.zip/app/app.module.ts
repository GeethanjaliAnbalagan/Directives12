import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // Import FormsModule
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { InputChildComponent } from './input-decorator/inputchild.component';
import { InputParentComponent } from './input-decorator/inputparent.component';
import { OutputChildComponent } from './Output-decorator/outputchild.component';
import { OutputParentComponent } from './Output-decorator/outputparent.component';
import { ProductListComponent } from './Directives/product-list.component';
import { ProductSwitchComponent } from './Directives/product-switch.component';
import { ProductIfComponent } from './Directives/product-if.component';
import { ProductNgClassComponent } from './Directives/product-ng-class.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    InputParentComponent,
    InputChildComponent,
    OutputParentComponent,
    OutputChildComponent,
    ProductListComponent,
    ProductSwitchComponent,
    ProductIfComponent,
    ProductNgClassComponent


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent, ProductComponent]
})
export class AppModule { }
