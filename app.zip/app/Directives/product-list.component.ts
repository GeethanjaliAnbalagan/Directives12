// product-list.component.ts
import { Component } from '@angular/core';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',

})
export class ProductListComponent {
    products: any[] = [
        { name: 'Product 1', price: 10.99 },
        { name: 'Product 2', price: 19.99 },
        { name: 'Product 3', price: 24.99 }
    ];
}
