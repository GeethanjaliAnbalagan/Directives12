// product-ng-class.component.ts
import { Component } from '@angular/core';

@Component({
    selector: 'app-product-ng-class',
    templateUrl: './product-ng-class.component.html',
    styleUrls: ['./product-ng-class.component.css']
})
export class ProductNgClassComponent {
    products: any[] = [
        { name: 'Product 1', price: 10.99, inStock: true },
        { name: 'Product 2', price: 19.99, inStock: false },
        { name: 'Product 3', price: 24.99, inStock: true }
    ];
}
