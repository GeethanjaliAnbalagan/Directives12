// product-if.component.ts
import { Component } from '@angular/core';

@Component({
    selector: 'app-product-if',
    templateUrl: './product-if.component.html',

})
export class ProductIfComponent {
    product: any = null;

    setProduct(productId: number) {
        // Simulating fetching product details from an API based on productId
        if (productId === 1) {
            this.product = { id: 1, name: 'Product 1', description: 'Lorem ipsum dolor sit amet.', price: 10.99 };
        } else if (productId === 2) {
            this.product = { id: 2, name: 'Product 2', description: 'consectetur adipiscing elit.', price: 19.99 };
        } else if (productId === 3) {
            this.product = { id: 3, name: 'Product 3', description: 'Ut enim ad minim veniam.', price: 24.99 };
        } else {
            this.product = null; // If productId is not valid, reset product
        }
    }
}
