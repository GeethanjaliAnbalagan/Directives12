// outputchild.component.ts

import { Component, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-output-child',
    template: `
    <div>
      <h2>Child Component</h2>
      <button (click)="emitEvent()">Emit Event</button>
    </div>
  `
})
export class OutputChildComponent {
    @Output() childEvent = new EventEmitter<string>();

    emitEvent() {
        this.childEvent.emit('Data from child');
    }
}
